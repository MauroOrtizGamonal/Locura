#crea una clase llamada Producto
#nombre, unidades y precio
#creas un producto camisa, 10, 9.95 de precio
#muestra el nombre de producto por consola

#crea un método de infoProducto. Muestra el nombre, unidades, precio y inventario valorado (uxp)

#práctica de sobreescritura.
#crea una clase llamada Servicio
#tiene un método llamado consultarDetalle que muestra. el servicio es básico.
#la empresa tiene dos servicios. estándar y premium. Son dos clases que derivan de Servicio
#la clase Estandar y Premium tienen un método llamado consultarDetalle y explican que son
#servicio estándar y premium respectivamente.
#pide por consola un servicio. Elegimos premium y te muestra el resultado de consultarDetalle

class Producto:
    def __init__(self,nombre,unidades,precio):
        self.nombre=nombre
        self.unidades=unidades
        self.precio=precio

    def mostrarNombre(self):
        print(f'Has comprado el producto {self.nombre}, son {self.unidades} unidades y su precio es de {self.precio} euros')

producto1=Producto('Camisa',10,9.95)
producto1.mostrarNombre()

class Servicio:
    def consultarDetalle(self):
        print('¡El servicio es básico!')

class Estandar(Servicio):
    def consultarDetalle1(self):
        print('¡El servicio es estándar!')

class Premium(Servicio):
    def consultarDetalle2(self):
        print('¡El servicio es premium!')

servicio1=Servicio()
servicio2=Estandar()
servicio3=Premium()

servicio1.consultarDetalle()
servicio2.consultarDetalle1()
servicio3.consultarDetalle2()